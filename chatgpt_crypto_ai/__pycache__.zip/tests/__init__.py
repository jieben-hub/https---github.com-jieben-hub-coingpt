# -*- coding: utf-8 -*-
"""
CoinGPT - 区块链行情聊天机器人测试套件
"""
