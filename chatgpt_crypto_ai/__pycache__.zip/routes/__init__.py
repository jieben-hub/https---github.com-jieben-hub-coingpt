# -*- coding: utf-8 -*-
"""
CoinGPT 路由模块
此包包含处理API请求的Flask路由。
"""
